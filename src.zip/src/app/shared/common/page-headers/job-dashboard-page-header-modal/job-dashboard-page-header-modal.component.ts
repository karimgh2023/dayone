import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-job-dashboard-page-header-modal',
  templateUrl: './job-dashboard-page-header-modal.component.html',
  styleUrls: ['./job-dashboard-page-header-modal.component.scss']
})
export class JobDashboardPageHeaderModalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
