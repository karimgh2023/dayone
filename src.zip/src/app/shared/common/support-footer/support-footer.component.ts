import { Component } from '@angular/core';

@Component({
  selector: 'app-support-footer',
  templateUrl: './support-footer.component.html',
  styleUrl: './support-footer.component.scss'
})
export class SupportFooterComponent {

}
