export interface Plant {
    id: number;
    name: string;
    address: string;
  }
  